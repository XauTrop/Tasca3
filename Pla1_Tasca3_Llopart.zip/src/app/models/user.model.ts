export interface User {
    id: number;
    name: string;
    familyName: string;
    email: string
}
